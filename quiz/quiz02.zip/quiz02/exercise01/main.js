function showFox() {
    // your code here...
    console.log('Change image and paragraph to fox...');
    document.querySelector("img").src = "images/fox.jpg";
    document.querySelector("p").innerHTML = "Fox";
}

function showLion() {
    // your code here...
    console.log('Change image and paragraph to lion...');
    document.querySelector("img").src = "images/lion.jpg";
    document.querySelector("p").innerHTML = "Lion";
}

function showTiger() {
    // your code here...
    console.log('Change image and paragraph to tiger...');
    document.querySelector("img").src = "images/tiger.png";
    document.querySelector("p").innerHTML = "Tiger";
}

function showZebra() {
    // your code here...
    console.log('Change image and paragraph to zebra...');
    document.querySelector("img").src = "images/zebra.jpg";
    document.querySelector("p").innerHTML = "Zebra";
}

//